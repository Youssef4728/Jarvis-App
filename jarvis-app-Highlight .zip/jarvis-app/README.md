# Jarvis – Gerüst

1. In Supabase: erst `supabase/schema.sql`, dann `supabase/seed.sql` im SQL Editor ausführen.
2. `.env.example` nach `.env.local` kopieren und ausfüllen.
3. `npm install && npm run dev`
4. Auf Vercel deployen, dieselben Variablen eintragen. `CRON_SECRET` dort als Env-Variable setzen, Vercel schickt es automatisch als Bearer-Token.
5. Die Abend-Erinnerung läuft täglich um 19:00 UTC (21:00 Sommerzeit, 20:00 Winterzeit in Deutschland). Zeit in `vercel.json` anpassen.
6. Termine änderst du im Chat mit Claude oder direkt in Supabase (Tabellen `routines`, `events`, `breaks`). Gebetszeiten holt die App täglich automatisch (Ort in `lib/prayer.ts`).

## Agent-Version (v2)
- Zusätzlich `supabase/schema_v2.sql` ausführen (Tasks, Geld, Fitness, Gewohnheiten, Fakten).
- Telegram-Webhook setzen (einmal im Browser, Werte einsetzen):
  `https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://<DEINE-APP>.vercel.app/api/telegram&secret_token=<TELEGRAM_WEBHOOK_SECRET>`
- Jarvis antwortet dann direkt in Telegram und nutzt dabei seine Tools (Plan, Aufgaben, Geld, Fitness, Gedächtnis).
- Tagesstart 05:00 UTC, Abendcheck 19:00 UTC (Zeiten in `vercel.json`).
- Broker: noch offen. Sobald du einen Broker mit Schnittstelle hast, wird er in `lib/tools.ts` angebunden (aktuell Platzhalter für Alpaca, optional).
