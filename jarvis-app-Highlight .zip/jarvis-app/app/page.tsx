"use client";
import { useEffect, useState } from "react";

type Item = { title: string; time: string | null; category: string };

export default function Home() {
  const [pw, setPw] = useState("");
  const [plan, setPlan] = useState<{ date: string; items: Item[] } | null>(null);
  const [chat, setChat] = useState<{ role: string; text: string }[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => { setPw(localStorage.getItem("pw") ?? ""); }, []);
  useEffect(() => {
    if (!pw) return;
    fetch("/api/tomorrow", { headers: { "x-app-password": pw } }).then((r) => r.ok ? r.json() : null).then(setPlan);
  }, [pw]);

  async function send() {
    if (!input.trim() || busy) return;
    const text = input; setInput(""); setBusy(true);
    setChat((c) => [...c, { role: "user", text }]);
    const r = await fetch("/api/chat", { method: "POST", headers: { "x-app-password": pw, "Content-Type": "application/json" }, body: JSON.stringify({ message: text }) });
    const j = r.ok ? await r.json() : { reply: "Fehler: Passwort oder Server prüfen." };
    setChat((c) => [...c, { role: "assistant", text: j.reply }]);
    setBusy(false);
  }

  if (!pw) return (
    <main style={{ padding: 20 }}>
      <h1>Jarvis</h1>
      <input type="password" placeholder="Passwort" onKeyDown={(e) => { if (e.key === "Enter") { localStorage.setItem("pw", e.currentTarget.value); setPw(e.currentTarget.value); } }} style={{ padding: 12, width: "100%", boxSizing: "border-box" }} />
    </main>
  );

  return (
    <main style={{ padding: 20, maxWidth: 560, margin: "0 auto" }}>
      <h2 style={{ marginBottom: 4 }}>Morgen</h2>
      <p style={{ marginTop: 0, opacity: 0.6 }}>{plan?.date}</p>
      {plan?.items.length ? plan.items.map((i, k) => (
        <div key={k} style={{ display: "flex", gap: 12, padding: "10px 0", borderBottom: "1px solid #232a34" }}>
          <span style={{ width: 52, opacity: 0.6 }}>{i.time?.slice(0, 5) ?? "–"}</span><span>{i.title}</span>
        </div>
      )) : <p style={{ opacity: 0.6 }}>Noch nichts eingetragen.</p>}

      <h2 style={{ marginTop: 32 }}>Chat</h2>
      {chat.map((m, k) => (
        <p key={k} style={{ background: m.role === "user" ? "#1c2430" : "transparent", padding: 10, borderRadius: 8, whiteSpace: "pre-wrap" }}>{m.text}</p>
      ))}
      <div style={{ display: "flex", gap: 8 }}>
        <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} placeholder="Schreib Jarvis…" style={{ flex: 1, padding: 12 }} />
        <button onClick={send} disabled={busy} style={{ padding: "12px 16px" }}>Senden</button>
      </div>
    </main>
  );
}
