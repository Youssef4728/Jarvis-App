import { runAgent } from "@/lib/agent";
import { sendTelegram } from "@/lib/telegram";
export const dynamic = "force-dynamic";
export const maxDuration = 60;
export async function POST(req: Request) {
  if (req.headers.get("x-telegram-bot-api-secret-token") !== process.env.TELEGRAM_WEBHOOK_SECRET) return new Response("Nein", { status: 401 });
  const u = await req.json();
  const msg = u.message;
  if (!msg?.text || String(msg.chat.id) !== process.env.TELEGRAM_CHAT_ID) return Response.json({ ok: true });
  await sendTelegram(await runAgent(msg.text));
  return Response.json({ ok: true });
}
