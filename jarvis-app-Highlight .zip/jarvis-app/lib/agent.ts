import Anthropic from "@anthropic-ai/sdk";
import { supabase } from "./supabase";
import { TOOLS, runTool } from "./tools";

const client = new Anthropic();

export async function runAgent(text: string, save = true) {
  const [facts, hist] = await Promise.all([
    supabase.from("facts").select("text"),
    supabase.from("messages").select("role,content").order("id", { ascending: false }).limit(20),
  ]);
  const past = (hist.data ?? []).reverse().map((m) => ({ role: m.role as "user" | "assistant", content: m.content }));
  while (past.length && past[0].role !== "user") past.shift();
  const messages: Anthropic.MessageParam[] = [...past, { role: "user", content: text }];
  const system =
    "Du bist Jarvis, der persönliche Assistent von Youssef: direkt, konkret, motivierend, auf Deutsch, kurz. " +
    "Du hast Tools für Plan, Aufgaben, Geld, Fitness, Gewohnheiten und Gedächtnis. Nutze sie, statt zu raten, und trage Dinge direkt ein, wenn er sie erwähnt. " +
    "Heute ist " + new Date().toISOString().slice(0, 10) + ". Gesundheit: Wade (möglicher Muskelfaserriss) und Rücken schonen. " +
    "Bei Geld und Trading rechnest du ehrlich vor und führst keine Orders aus. Gemerkte Fakten:\n" +
    ((facts.data ?? []).map((f) => "- " + f.text).join("\n") || "(noch keine)");

  for (let step = 0; step < 6; step++) {
    const res = await client.messages.create({ model: "claude-sonnet-5-5", max_tokens: 1200, system, tools: TOOLS, messages });
    if (res.stop_reason !== "tool_use") {
      const out = res.content.map((c) => (c.type === "text" ? c.text : "")).join("");
      if (save) await supabase.from("messages").insert([{ role: "user", content: text }, { role: "assistant", content: out }]);
      return out;
    }
    messages.push({ role: "assistant", content: res.content });
    const results = await Promise.all(
      res.content.filter((c): c is Anthropic.ToolUseBlock => c.type === "tool_use").map(async (c) => ({
        type: "tool_result" as const,
        tool_use_id: c.id,
        content: await runTool(c.name, c.input).catch((e) => "Fehler: " + e.message),
      }))
    );
    messages.push({ role: "user", content: results });
  }
  return "Das war zu viele Schritte auf einmal, frag mich bitte etwas konkreter.";
}
