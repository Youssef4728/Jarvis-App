import type Anthropic from "@anthropic-ai/sdk";
import { supabase } from "./supabase";
import { loadTomorrow } from "./plan";

const str = (d: string, desc: string) => ({ type: "string" as const, description: desc });
const today = () => new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Berlin" }).format(new Date());

export const TOOLS: Anthropic.Tool[] = [
  { name: "get_plan", description: "Plan für morgen (Routinen, Termine, Gebetszeiten) plus Termine der nächsten 14 Tage.", input_schema: { type: "object", properties: {} } },
  { name: "add_event", description: "Trägt einen Termin ein.", input_schema: { type: "object", properties: { title: str("", "Titel"), day: str("", "YYYY-MM-DD"), time: str("", "HH:MM oder leer"), category: str("", "termin, fussball, privat, reise") }, required: ["title", "day"] } },
  { name: "add_task", description: "Fügt eine Aufgabe hinzu.", input_schema: { type: "object", properties: { text: str("", "Aufgabe"), due: str("", "YYYY-MM-DD oder leer") }, required: ["text"] } },
  { name: "list_tasks", description: "Listet offene Aufgaben.", input_schema: { type: "object", properties: {} } },
  { name: "complete_task", description: "Hakt eine Aufgabe ab (Textteil reicht).", input_schema: { type: "object", properties: { match: str("", "Teil des Aufgabentexts") }, required: ["match"] } },
  { name: "log_money", description: "Bucht Einnahme (positiv) oder Ausgabe (negativ) in Euro.", input_schema: { type: "object", properties: { amount: { type: "number" }, note: str("", "Wofür") }, required: ["amount"] } },
  { name: "finance_summary", description: "Verfügbares Geld, Ziele (Paris, Möbel) und letzte Buchungen.", input_schema: { type: "object", properties: {} } },
  { name: "log_gym", description: "Loggt Training oder Körpergewicht (exercise = 'Körpergewicht').", input_schema: { type: "object", properties: { exercise: str("", ""), kg: { type: "number" }, reps: { type: "number" }, sets: { type: "number" } }, required: ["exercise"] } },
  { name: "check_habit", description: "Hakt eine Gewohnheit für heute ab.", input_schema: { type: "object", properties: { habit: str("", "Name") }, required: ["habit"] } },
  { name: "save_fact", description: "Merkt sich einen dauerhaften Fakt über Youssef. Keine Passwörter oder Kontonummern.", input_schema: { type: "object", properties: { text: str("", "Fakt") }, required: ["text"] } },
  { name: "portfolio", description: "Liest Konto und Positionen vom Broker (nur lesen, keine Orders). Optional: nur nutzbar, wenn ein Broker verbunden ist.", input_schema: { type: "object", properties: {} } },
];

async function alpaca(path: string) {
  if (!process.env.ALPACA_KEY) throw new Error("Broker noch nicht verbunden");
  const r = await fetch("https://paper-api.alpaca.markets/v2" + path, {
    headers: { "APCA-API-KEY-ID": process.env.ALPACA_KEY!, "APCA-API-SECRET-KEY": process.env.ALPACA_SECRET! },
  });
  if (!r.ok) throw new Error("Alpaca " + r.status);
  return r.json();
}

export async function runTool(name: string, i: any): Promise<string> {
  switch (name) {
    case "get_plan": {
      const to = new Date(Date.now() + 14 * 864e5).toISOString().slice(0, 10);
      const { data } = await supabase.from("events").select("title,day,time,skipped").gte("day", today()).lte("day", to).order("day");
      return JSON.stringify({ morgen: await loadTomorrow(), naechste_termine: data });
    }
    case "add_event": await supabase.from("events").insert({ title: i.title, day: i.day, time: i.time || null, category: i.category || "termin" }); return "eingetragen";
    case "add_task": await supabase.from("tasks").insert({ text: i.text, due: i.due || null }); return "eingetragen";
    case "list_tasks": return JSON.stringify((await supabase.from("tasks").select("text,due").eq("done", false).order("due")).data);
    case "complete_task": { const { data } = await supabase.from("tasks").select("id").eq("done", false).ilike("text", `%${i.match}%`).limit(1); if (!data?.length) return "nicht gefunden"; await supabase.from("tasks").update({ done: true }).eq("id", data[0].id); return "erledigt"; }
    case "log_money": await supabase.from("money").insert({ amt: i.amount, note: i.note || null }); return "gebucht";
    case "finance_summary": {
      const [m, g] = await Promise.all([supabase.from("money").select("amt,note,day").order("day", { ascending: false }).limit(200), supabase.from("goals").select("name,target,saved")]);
      const bal = (m.data ?? []).reduce((s, x) => s + Number(x.amt), 0);
      return JSON.stringify({ verfuegbar: bal, ziele: g.data, letzte: (m.data ?? []).slice(0, 8) });
    }
    case "log_gym": await supabase.from("gym_logs").insert({ ex: i.exercise, kg: i.kg ?? 0, reps: i.reps ?? 0, sets: i.sets ?? 1 }); return "geloggt";
    case "check_habit": await supabase.from("habit_checks").upsert({ day: today(), habit: i.habit }); return "abgehakt";
    case "save_fact": await supabase.from("facts").insert({ text: String(i.text).slice(0, 300) }); return "gemerkt";
    case "portfolio": if (!process.env.ALPACA_KEY) return "Noch kein Broker verbunden."; return JSON.stringify({ konto: await alpaca("/account"), positionen: await alpaca("/positions") });
    default: return "unbekanntes Tool";
  }
}
