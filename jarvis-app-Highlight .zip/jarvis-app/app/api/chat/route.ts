import { runAgent } from "@/lib/agent";
export const dynamic = "force-dynamic";
export const maxDuration = 60;
export async function POST(req: Request) {
  if (req.headers.get("x-app-password") !== process.env.APP_PASSWORD) return new Response("Nein", { status: 401 });
  const { message } = await req.json();
  return Response.json({ reply: await runAgent(message) });
}
